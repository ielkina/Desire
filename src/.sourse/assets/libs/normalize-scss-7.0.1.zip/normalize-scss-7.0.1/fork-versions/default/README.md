# Fork-able normalize-scss<br> for libSass or Ruby Sass

## Using with node-sass or libSass or Ruby Sass

1. Copy these files to your Sass project.
2. Start forking by altering/moving Sass variables found in `_variables.scss`.
3. Edit any CSS ruleset directly rather than overriding it in later Sass.
