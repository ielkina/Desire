export default window.document;
