import arr from "./arr.js";

export default arr.pop;
